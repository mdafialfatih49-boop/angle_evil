# Kilau Gelap — Fabric 26.3

Mod contoh untuk Minecraft Java Edition 26.3 yang mendaftarkan dua mob baru:

- **Malaikat**: mob yang dapat terbang, memiliki partikel cahaya, dan berjalan-jalan/menoleh ke pemain tanpa menyerang.
- **Iblis**: mob darat yang bergerak lebih cepat, mengeluarkan partikel asap/api, dan menjauh dari pemain. Tidak menyerang pemain atau villager.

Kedua mob menjatuhkan item khusus saat mati. Proyek ini adalah **Fabric mod**, bukan datapack. Datapack biasa tidak dapat mendaftarkan kelas entity baru dengan model dan AI kustom seperti ini.

## Versi dan kebutuhan

- Minecraft Java Edition **26.3** (rilis stabil yang ditargetkan proyek)
- Fabric Loader **0.19.5 atau lebih baru**
- Fabric API **0.165.0+26.3**
- Java **25**
- Gradle **9.6.0**

## Perintah testing

Aktifkan cheats, lalu jalankan:

```mcfunction
/summon kilaugelap:angel ~ ~1 ~
/summon kilaugelap:demon ~ ~1 ~
/give @s kilaugelap:holy_feather 4
/give @s kilaugelap:essence_of_light 2
/give @s kilaugelap:demon_horn 4
/give @s kilaugelap:nether_ash 2
```

Peluang drop:

- Malaikat: 1–2 Bulu Suci; 22% Esensi Cahaya.
- Iblis: 1–2 Tanduk Iblis; 28% Abu Nether.

## Build dari Android melalui GitHub Actions

1. Ekstrak ZIP ini di ponsel.
2. Buat repository baru di GitHub.
3. Upload seluruh isi folder proyek ke repository (bukan folder ZIP-nya sebagai satu file).
4. Buka tab **Actions**. Izinkan Actions jika GitHub meminta.
5. Jalankan workflow **Build Fabric Mod** melalui **Run workflow**, atau push perubahan ke branch `main`.
6. Setelah workflow hijau, buka run tersebut, turun ke bagian **Artifacts**, lalu unduh `kilau-gelap-minecraft-26.3`. Artifact ini berisi JAR mod utama `kilau-gelap-1.0.0.jar`.
7. Ekstrak artifact. File `.jar` hasil build ada di dalamnya.
8. Pasang `.jar` ke folder `mods` pada instalasi Minecraft Java + Fabric 26.3, bersama Fabric API yang cocok.

> Build dijalankan di runner GitHub, jadi Android tidak perlu memasang JDK/Gradle secara lokal. Ponsel hanya dipakai untuk mengunggah source dan mengunduh artifact.

## Catatan fitur

Versi ini berfokus pada entity kustom, visual, partikel, roaming/flight, dan loot. AI serangan, proyektil, dan efek damage tidak disertakan. Model/tekstur yang ada merupakan model dasar yang bisa dikembangkan lebih lanjut.
