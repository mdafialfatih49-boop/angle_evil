package id.dafi.kilaugelap.client;

import id.dafi.kilaugelap.client.model.AngelModel;
import id.dafi.kilaugelap.client.model.DemonModel;
import id.dafi.kilaugelap.client.model.ModEntityModelLayers;
import id.dafi.kilaugelap.client.renderer.AngelRenderer;
import id.dafi.kilaugelap.client.renderer.DemonRenderer;
import id.dafi.kilaugelap.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

public class KilauGelapClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(ModEntityModelLayers.ANGEL, AngelModel::createBodyLayer);
        ModelLayerRegistry.registerModelLayer(ModEntityModelLayers.DEMON, DemonModel::createBodyLayer);

        EntityRenderers.register(ModEntities.ANGEL, AngelRenderer::new);
        EntityRenderers.register(ModEntities.DEMON, DemonRenderer::new);
    }
}
