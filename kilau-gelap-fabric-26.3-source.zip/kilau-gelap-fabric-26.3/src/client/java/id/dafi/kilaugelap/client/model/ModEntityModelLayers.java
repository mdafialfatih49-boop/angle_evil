package id.dafi.kilaugelap.client.model;

import id.dafi.kilaugelap.KilauGelap;
import net.minecraft.client.model.geom.ModelLayerLocation;

public final class ModEntityModelLayers {
    public static final ModelLayerLocation ANGEL = new ModelLayerLocation(KilauGelap.id("angel"), "main");
    public static final ModelLayerLocation DEMON = new ModelLayerLocation(KilauGelap.id("demon"), "main");

    private ModEntityModelLayers() {}
}
