package id.dafi.kilaugelap.client.renderer;

import id.dafi.kilaugelap.KilauGelap;
import id.dafi.kilaugelap.client.model.AngelModel;
import id.dafi.kilaugelap.client.model.ModEntityModelLayers;
import id.dafi.kilaugelap.entity.AngelEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class AngelRenderer extends MobRenderer<AngelEntity, LivingEntityRenderState, AngelModel> {
    private static final Identifier TEXTURE = KilauGelap.id("textures/entity/angel.png");

    public AngelRenderer(EntityRendererProvider.Context context) {
        super(context, new AngelModel(context.bakeLayer(ModEntityModelLayers.ANGEL)), 0.35F);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
