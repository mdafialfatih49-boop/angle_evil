package id.dafi.kilaugelap;

import id.dafi.kilaugelap.entity.AngelEntity;
import id.dafi.kilaugelap.entity.DemonEntity;
import id.dafi.kilaugelap.registry.ModEntities;
import id.dafi.kilaugelap.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public class KilauGelap implements ModInitializer {
    public static final String MOD_ID = "kilaugelap";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModEntities.initialize();
        registerDrops();
    }

    private static void registerDrops() {
        ServerLivingEntityEvents.AFTER_DEATH.register((LivingEntity entity, net.minecraft.world.damagesource.DamageSource source) -> {
            if (!(entity.level() instanceof ServerLevel serverLevel)) {
                return;
            }

            if (entity instanceof AngelEntity) {
                drop(serverLevel, entity, ModItems.HOLY_FEATHER, 1 + entity.getRandom().nextInt(2));
                if (entity.getRandom().nextFloat() < 0.22F) {
                    drop(serverLevel, entity, ModItems.ESSENCE_OF_LIGHT, 1);
                }
            } else if (entity instanceof DemonEntity) {
                drop(serverLevel, entity, ModItems.DEMON_HORN, 1 + entity.getRandom().nextInt(2));
                if (entity.getRandom().nextFloat() < 0.28F) {
                    drop(serverLevel, entity, ModItems.NETHER_ASH, 1);
                }
            }
        });
    }

    private static void drop(ServerLevel level, LivingEntity entity, net.minecraft.world.item.Item item, int count) {
        ItemStack stack = new ItemStack(item, count);
        ItemEntity itemEntity = new ItemEntity(level, entity.getX(), entity.getY(), entity.getZ(), stack);
        level.addFreshEntity(itemEntity);
    }
}
