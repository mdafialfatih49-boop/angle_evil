package id.dafi.kilaugelap.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class DemonEntity extends PathfinderMob {
    public DemonEntity(EntityType<? extends DemonEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D);
    }

    @Override
    protected void registerGoals() {
        // Iblis ini bersifat menghindar: tidak menyerang pemain atau villager.
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 8.0F, 1.15D, 1.55D));
        this.goalSelector.addGoal(2, new RandomStrollGoal(this, 1.05D));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide && this.getRandom().nextInt(2) == 0) {
            this.level().addParticle(
                    this.getRandom().nextBoolean() ? ParticleTypes.SMOKE : ParticleTypes.FLAME,
                    this.getX() + (this.getRandom().nextDouble() - 0.5D) * 0.7D,
                    this.getY() + this.getRandom().nextDouble() * 1.5D,
                    this.getZ() + (this.getRandom().nextDouble() - 0.5D) * 0.7D,
                    0.0D, 0.015D, 0.0D
            );
        }
    }
}
